package org.ghsdaskakalan.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.math.BigDecimal;

public class MainActivity extends Activity {
    private TextView expressionView, resultView;
    private String current = "0", stored = "";
    private String operator = "";
    private boolean freshInput = true, error = false;
    private final int bg = Color.rgb(16, 29, 43);
    private final int panel = Color.rgb(25, 42, 58);
    private final int teal = Color.rgb(25, 183, 165);
    private final int pale = Color.rgb(225, 237, 242);
    private final int muted = Color.rgb(143, 164, 178);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackgroundColor(bg);
        setContentView(root);

        TextView brand = new TextView(this);
        brand.setText("GHS DASKA KALAN");
        brand.setTextColor(teal);
        brand.setTextSize(14);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setLetterSpacing(.12f);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, dp(34)));

        TextView subtitle = new TextView(this);
        subtitle.setText("SIMPLE • SMART • CALCULATOR");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(10);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLetterSpacing(.10f);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(24)));

        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.BOTTOM | Gravity.RIGHT);
        display.setPadding(dp(18), dp(16), dp(18), dp(18));
        display.setBackground(shape(panel, dp(22)));
        LinearLayout.LayoutParams displayLp = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        displayLp.setMargins(0, dp(20), 0, dp(18));
        root.addView(display, displayLp);

        expressionView = new TextView(this);
        expressionView.setTextColor(muted);
        expressionView.setTextSize(18);
        expressionView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.addView(expressionView, new LinearLayout.LayoutParams(-1, dp(42)));

        resultView = new TextView(this);
        resultView.setText("0");
        resultView.setTextColor(pale);
        resultView.setTextSize(48);
        resultView.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        resultView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        resultView.setSingleLine(true);
        resultView.setTextIsSelectable(false);
        display.addView(resultView, new LinearLayout.LayoutParams(-1, dp(72)));

        String[][] keys = {
            {"AC", "⌫", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"±", "0", ".", "="}
        };
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(5);
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1.55f));

        for (int r = 0; r < keys.length; r++) {
            for (int c = 0; c < 4; c++) {
                String key = keys[r][c];
                Button b = new Button(this);
                b.setText(key);
                b.setAllCaps(false);
                b.setTextSize(22);
                b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                b.setTextColor(key.equals("=") ? Color.WHITE : (isOperator(key) || key.equals("AC") || key.equals("⌫") || key.equals("%") || key.equals("±") ? teal : pale));
                int color = key.equals("=") ? teal : (isOperator(key) ? Color.rgb(35, 65, 78) : panel);
                b.setBackground(shape(color, dp(18)));
                b.setStateListAnimator(null);
                b.setPadding(0, 0, 0, 0);
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(r, 1, 1f), GridLayout.spec(c, 1, 1f));
                lp.width = 0;
                lp.height = 0;
                lp.setMargins(dp(5), dp(5), dp(5), dp(5));
                grid.addView(b, lp);
                b.setOnClickListener(v -> press(key));
            }
        }

        TextView footer = new TextView(this);
        footer.setText("Developed by GHS Daska Kalan");
        footer.setTextColor(muted);
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(34));
        fp.topMargin = dp(8);
        root.addView(footer, fp);
    }

    private boolean isOperator(String s) {
        return s.equals("÷") || s.equals("×") || s.equals("+") || s.equals("−");
    }

    private void press(String key) {
        if (key.equals("AC")) { clear(); return; }
        if (key.equals("⌫")) {
            if (error) { clear(); return; }
            if (!freshInput && current.length() > 1) current = current.substring(0, current.length()-1);
            else current = "0";
            update(); return;
        }
        if (key.equals("±")) {
            if (!current.equals("0")) current = current.startsWith("-") ? current.substring(1) : "-" + current;
            update(); return;
        }
        if (key.equals("%")) {
            try { current = clean(Double.parseDouble(current) / 100.0); update(); }
            catch (Exception e) { showError(); }
            return;
        }
        if (isOperator(key)) {
            if (error) return;
            if (!operator.isEmpty() && !freshInput) calculate();
            stored = current;
            operator = key;
            freshInput = true;
            expressionView.setText(stored + " " + operator);
            return;
        }
        if (key.equals("=")) {
            if (operator.isEmpty() || stored.isEmpty() || error) return;
            String left = stored, op = operator, right = current;
            calculate();
            expressionView.setText(left + " " + op + " " + right + " =");
            operator = ""; stored = ""; freshInput = true;
            return;
        }
        if (error) clear();
        if (freshInput) { current = key.equals(".") ? "0." : key; freshInput = false; }
        else if (key.equals(".")) { if (!current.contains(".")) current += "."; }
        else current = current.equals("0") ? key : current + key;
        if (current.length() > 14) current = current.substring(0, 14);
        update();
    }

    private void calculate() {
        try {
            double a = Double.parseDouble(stored), b = Double.parseDouble(current), value;
            switch (operator) {
                case "+": value = a + b; break;
                case "−": value = a - b; break;
                case "×": value = a * b; break;
                case "÷": if (b == 0) { showError(); return; } value = a / b; break;
                default: return;
            }
            current = clean(value);
            update();
            freshInput = true;
        } catch (Exception e) { showError(); }
    }

    private String clean(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return "Error";
        return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
    }

    private void showError() {
        current = "Error"; error = true; operator = ""; stored = "";
        resultView.setText(current);
        expressionView.setText("Cannot divide by zero");
    }

    private void clear() {
        current = "0"; stored = ""; operator = "";
        freshInput = true; error = false;
        expressionView.setText(""); update();
    }

    private void update() {
        if (resultView != null) resultView.setText(current);
        if (error) return;
        if (operator.isEmpty()) expressionView.setText("");
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
