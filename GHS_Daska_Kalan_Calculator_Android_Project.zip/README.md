# GHS Daska Kalan Calculator

A simple, elegant native Android calculator branded for **GHS Daska Kalan**.

## Features
- Addition, subtraction, multiplication and division
- Percentage, sign toggle, decimal point and backspace
- Clear and equals
- Dark navy interface with teal accents
- Footer credit: Developed by GHS Daska Kalan
- Minimum Android version: Android 6.0 (API 23)

## Build an installable APK
This workspace could not compile the APK because Android SDK/Gradle build tools are not installed in the build environment and external downloads are unavailable.

1. Install **Android Studio** on a computer.
2. Open this project folder (`GHSDaskaKalanCalculator`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will create the APK at:
   `app/build/outputs/apk/debug/app-debug.apk`

For a distributable signed APK, choose **Build → Generate Signed Bundle / APK → APK**.
